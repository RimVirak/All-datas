<?php /* C:\xampp\htdocs\final2019\final2019\resources\views/students/show.blade.php */ ?>

  <?php $__env->startSection('content'); ?>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<div class="container mt-5">
<a href="<?php echo e(route('student.create')); ?>" class="btn btn-success text-white" method="POST">New Student</a>

    <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   
        <div class="card mt-4 shadow-lg ">
            <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Email</th>
                <th>Course</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php echo csrf_field(); ?>
            <?php echo method_field('delete'); ?>

              <td></td>
              <td><?php echo e($item['title']); ?></td>
              <td><?php echo e($item['email']); ?></td>
              <td><?php echo e($item['course']); ?></td>
              <td> 
                   <a href="<?php echo e(route('student.edit',$item->id)); ?>" class="btn btn-info btn-sm float-left text-white">Update</a>
                   <a href="<?php echo e(route('student.destroy',$item->id)); ?>" type="submit" class="btn btn-sm float-left btn-danger">Delete"></a>
               </td>
        </tbody>     
            
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
