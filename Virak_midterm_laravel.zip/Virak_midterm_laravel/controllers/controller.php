
<?php

 function show(){
    $result['add_con']= show_student();
    return   $result['add_con'];
 }
 function add(){
      $result=Add_student();
    if($result){
       header('location:index.php');
    }else  {
        echo "error";
   }
 }
?>
