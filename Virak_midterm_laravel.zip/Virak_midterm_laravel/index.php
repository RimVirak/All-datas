<?php
session_start();
include_once ('controllers/controller.php');
include_once ('models/model.php');
include_once ('views/templete.php');
include_once ('connection.php');
?>