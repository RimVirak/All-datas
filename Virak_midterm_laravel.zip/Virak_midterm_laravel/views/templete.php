<?php
include "page/show.php";

?>