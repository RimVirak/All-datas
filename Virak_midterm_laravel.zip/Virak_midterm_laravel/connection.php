<?php

$server="localhost";
$username="root";
$password="";
$dbname="midterm_mvc_exam";
$con=mysqli_connect($server,$username,$password,$dbname);

// if($con){
//      echo 'connected';
// }else{
//      echo 'can not connnect';
// }




?>