<footer class="site-footer">

      <h4><a href="<?php the_permalink(); ?>">
      <?php the_title();?></a>|</h4>
    <p><?php bloginfo('name')?>-&copy;<?php echo date('Y');?></p>
</footer>
</div>

<?php wp_footer();?>
</body>
</html>