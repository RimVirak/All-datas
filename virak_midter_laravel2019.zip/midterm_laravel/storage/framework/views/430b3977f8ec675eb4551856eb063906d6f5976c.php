<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Post Index</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

</head>
<body>
     
    <div class="bg-info text-white p-5">
         <a href="<?php echo e(route('posts.index')); ?>" class='btn btn-secondary'>Home</a>
         <a href="<?php echo e(route('posts.create')); ?>" class='btn btn-secondary'>Create Post</a>
    </div>
    <div class="container">
    <?php echo $__env->yieldContent('content'); ?>
    </div>
</body>
</html>