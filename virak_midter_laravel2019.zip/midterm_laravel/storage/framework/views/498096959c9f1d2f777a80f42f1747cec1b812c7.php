     <?php $__env->startSection('content'); ?>
         <h1>All Post here</h1>
         <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <div class="card">
            <div class="card-body">
               <p>
                 <h6>
                   <a href="<?php echo e(route('posts.show', $post->id)); ?>">
                       <?php echo e($post->title); ?>

                   </a>
                   <a href="<?php echo e(route('posts.edit',$post->id)); ?>" class="btn btn-info btn-sm">Edit</a>
                    <form onsubmit="return confirm('Are you sure you want to delete this post?')" class=" d-inline-block" method="POST" action="<?php echo e(route('posts.destroy',$post->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                    </form>
                </h6>
               </p>
            </div>
         </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <div class="mt-4">
               <?php echo e($posts->links()); ?>

          </div>
   <?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>