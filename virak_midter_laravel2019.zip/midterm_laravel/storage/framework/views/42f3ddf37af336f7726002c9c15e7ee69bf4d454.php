<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-header">
     <h2><?php echo e($post->title); ?></h2>
  </div>
  <div class="card-body">
    <p>
       <?php echo e($post->content); ?>

    </p>
  </div>
 </div>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>