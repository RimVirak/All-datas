<?php

    include_once("src/GetValue.php");


    $name = $_POST['name'];
    $gender = $_POST['gender'];
    $province = $_POST['province'];
    $email = $_POST['email'];
    
	$got = new getValue($name, $gender, $province,$email);

	$Gotname = $got->Getname();
	$Gotgender = $got->Getgender();
	$Gotprovince = $got->Getprovince();
	$Gotemail = $got->Getemail();
	
?>
<?php include_once("header.php");?>
<div class="container mt-5">
       <p>Name<?php echo $Getname;?></p>
       <p>Gender<?php echo $Getgender;?></p>
       <p>Province<?php echo $Getprovince;?></p>
       <p>Email<?php echo $Getemail;?></p>
</div>  
<?php include_once("footer.php");?>