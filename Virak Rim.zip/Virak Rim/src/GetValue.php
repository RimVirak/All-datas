<?php
		class GetValue{
			public $name;
			public $gender;
			public $province;
			public $email;
	

			public function __construct($name, $gender, $province,$email){
				$this->name = $name;
				$this->gender = $gender;
				$this->province = $province;
				$this->email = $email;

			}
			
			public function Getname(){
				return $this->name;
			}

			public function Getgender(){
				return $this->gender;
			}
			public function Getprovince(){
				return $this->province;
			}
			public function Getemail(){
				return $this->email;
			}
			
		}
		