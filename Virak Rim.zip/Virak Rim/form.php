<?php

    include_once("src/GetValue.php");
    
?>
<?php include_once("header.php");?>
<div class="container mt-5">
    <div class="card">
    <div class="row">
        <div class="col-md-4"></div>
        <!-- <div class="col-md-4 form-style"> -->
        <div class="card-body">
        <form>
          <div class="form-group">
            <label for="#" type="text" name="name"> Name</label>
            <input type="name" class="form-control" id="exampleInputEmail1" aria-describedby="name" placeholder="Enter your name " required>
            </div>
            <div class="form-group">
              <label for="#" type="text" name="gender">Gender</label>
              <input type="text" class="form-control" id="exampleInputPassword1" placeholder="Enter your gender" required>
            </div>
            <div class="form-group">
              <label for="#" type="text" name="province">Province</label>
              <input type="text" class="form-control" id="exampleInputPassword1" placeholder="Enter your province" required>
            </div>
            <div class="form-group">
              <label for="" type="text" name="email">Email</label>
              <input type="email" class="form-control" id="email" placeholder="Enter your email" required>
            </div>
            <button type="submit" class="btn btn-primary" name="submit">Send</button>
        </form>
    </div>
      <div class="col-md-4"></div>
</div>
<div class="container mt-5">
    <div class="card">
    <div class="row">
        <div class="col-md-4"></div>
        <!-- <div class="col-md-4 form-style"> -->
        <div class="card-body">
        <form>
          <div class="form-group">
            <label for="#" type="text" name="name"> Name:</label>
            </div>
            <div class="form-group">
              <label for="#" type="text" name="gender">Gender:</label>
            </div>
            <div class="form-group">
              <label for="#" type="text" name="province">Province:</label>
            </div>
            <div class="form-group">
              <label for="" type="text" name="email">Email:</label>
            </div>
        </form>
    </div>
    </div>
      <div class="col-md-4"></div>
</div>
</div>  
<?php include_once("footer.php");?>