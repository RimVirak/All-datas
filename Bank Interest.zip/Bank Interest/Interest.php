<?php
    interface Interest{
        public function calculate($capital, $duration, $interestRate);
        
    }

?>